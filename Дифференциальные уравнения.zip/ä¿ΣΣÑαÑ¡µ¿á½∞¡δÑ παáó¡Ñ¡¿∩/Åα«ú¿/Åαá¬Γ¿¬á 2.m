t0=-5; tfin = 5; n=10;
t=linspace(t0, tfin, n);  
figure(1),
%y1(t)=(3*cos(t)+2*sin(t)).*exp(t);
%y2(t)=(-2*cos(t)+3sin(t)).*exp(t);
plot(t,y1,'black','LineWidth',1),
hold on,
plot(t,y2,'black','LineWidth',1), 
hold on, 
ylabel('y'), xlabel('t'), 
legend('y1(t)=(1+t).*exp(t)', 'y2(t)=(1+2*t).*exp(t)', 'u'), 
hold off,
