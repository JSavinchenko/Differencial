[t,y]=ode45(@dif,[t0,tfin],y0); 
plot(t,y, '--r'), 
grid on, 
hold on 
pause, 

%function f = dif(~,y) 
    %a=1; b=2; c=0; g=1; 
    %dy1 = a*y(1)+b*y(2); 
    %dy2 = c*y(1)+g*y(2); 
    %f=[dy1;dy2]; 
%end 