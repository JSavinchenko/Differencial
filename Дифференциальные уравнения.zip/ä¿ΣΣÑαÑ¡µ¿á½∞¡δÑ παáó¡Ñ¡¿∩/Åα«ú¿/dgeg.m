f1 = @(t,y1,y2) y1 - 2*y2 - t; 
f2 = @(t,y1,y2) y2 - t; 
y10 = 0; 
y20 = 0; 
t0 = 0; 
tfin = 5; 
kol = 40; 
eps = 0.05; 
h = (tfin-t0)/kol; 
T = t0; 
Y1 = y10; 
Y2 = y20 ; 
i = 1; k = 0; 
while T(end) <= tfin 
while 1 
K1 = h*f1( T(i),Y1(i),Y2(i) ); 
L1 = h*f2( T(i),Y1(i),Y2(i) ); 
K2 = h*f1( T(i)+h/2, Y1(i)+K1/2, Y2(i)+L1/2); 
L2 = h*f2( T(i)+h/2, Y1(i)+K1/2, Y2(i)+L1/2); 
K3 = h*f1( T(i)+h/2, Y1(i)+K2/2, Y2(i)+L2/2); 
L3 = h*f2( T(i)+h/2, Y1(i)+K2/2, Y2(i)+L2/2); 
K4 = h*f1( T(i)+h, Y1(i)+K3, Y2(i)+L3); 
L4 = h*f2( T(i)+h, Y1(i)+K3, Y2(i)+L3); 
y11 = Y1(i) + (K1 + 2*K2 + 2*K3 + K4)/6; 
y12 = Y2(i) + (L1 + 2*L2 + 2*L3 + L4)/6; 
h = h/2; 
K1 = h*f1( T(i),Y1(i),Y2(i) ); 
L1 = h*f2( T(i),Y1(i),Y2(i) ); 
K2 = h*f1( T(i)+h/2, Y1(i)+K1/2, Y2(i)+L1/2); 
L2 = h*f2( T(i)+h/2, Y1(i)+K1/2, Y2(i)+L1/2); 
K3 = h*f1( T(i)+h/2, Y1(i)+K2/2, Y2(i)+L2/2); 
L3 = h*f2( T(i)+h/2, Y1(i)+K2/2, Y2(i)+L2/2); 
K4 = h*f1( T(i)+h, Y1(i)+K3, Y2(i)+L3); 
L4 = h*f2( T(i)+h, Y1(i)+K3, Y2(i)+L3); 
y21 = Y1(i) + (K1 + 2*K2 + 2*K3 + K4)/6; 
y22 = Y2(i) + (L1 + 2*L2 + 2*L3 + L4)/6; 
if max(abs([y11-y21, y12-y22])) > eps 
h = h/2; 
else 
h = 2*h; 
T(i+1) = T(i) + h; 
Y1(i+1) = y11; 
Y2(i+1) = y12; 
break 
end 
end 
i = i+1; 
h = 2*h; 
k = k+1; 
if k > 10000 
disp('������� �� ������� (�������� ����� ��������)') 
break 
end 
end 
plot(T,Y1,':g', T,Y2, ':g', 'LineWidth', 3) 
grid on 
legend('y1(t)','y2(t)'); 
title('����� �����-����� 4-�� �������') 
xlabel('T') 
ylabel('Y') 