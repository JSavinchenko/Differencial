t = linspace(0, 7);
y1 = (2.*cos(2.*t) + sin(2.*t)).* exp(t);
y2 = (cos(2.*t) - 2.*sin(2.*t)).* exp(t);
plot(y1, y2),
grid on,
xlabel('y1'),
ylabel('y2'),
hold off; 